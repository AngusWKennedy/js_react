import React from 'react'
import {Link, Outlet} from "react-router-dom"

export default function Layout() {
  return (
    <>
        <header className='bg-black p-4 w-full text-white gap-10 flex items-center'>
            <Link to="/">Counter</Link>
            <Link to="/todo-list">To Do List</Link>
            <Link to="/contacts">Contacts</Link>
            <Link to="/github-app">Github App</Link>
        </header>
        <div>
            <Outlet />
        </div>
    </>
  )
}
