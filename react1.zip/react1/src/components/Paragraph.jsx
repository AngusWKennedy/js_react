import React from 'react'

export default function Paragraph(props) {
    return (
      <p>
          {props.content}
      </p>
    )
  }