import React from 'react'

export default function Heading(props) {
  return (
    <h1>
        {props.content}
    </h1>
  )
}
