import React, {createContext, useContext, useState} from 'react'



function UserDetails()
    {
        const {userData} = useContext(GithubAppContext)

        return(
            userData.id && (
                <div className = "mt-6 bg-slate-300 px-5 py-5">
                    <div className = "flex items-center gap-4 ">
                        <img src={userData.avatar_url} alt="User Image" id="image" className = "w-24 h-24 rounded object-cover"/>
                        <h3 className="text-gray-900 font-semibold" id="name">{userData.name}</h3>
                    </div>

                    <ul>
                        <li className="flex items-center gap-4">
                        <h3 className="text-gray-900 font-semibold" id="name">Bio:</h3>
                            <span>{userData.bio}</span>
                            <span id="bio"></span>
                        </li>

                        <li className="flex items-center gap-4">
                            <h3 className="text-gray-900 font-semibold" id="name">Public Repos:</h3>
                            <span>{userData.public_repos}</span>
                            <span id="public-repos"></span>
                        </li>
                    </ul>
            </div>)
        )
    }

    function ErrorMessage()
    {
        const {errorMessage} = useContext(GithubAppContext)
        
        return (
            <span className='text-red-500 font-semibold my-2 px-5'>
            {errorMessage}
            </span>
        )
    }

    function SearchForm()
    {
        const {setUserData, setErrorMessage} = useContext(GithubAppContext)

        function handleSubmit(event)
        {
            event.preventDefault()

            setErrorMessage("")
            setUserData({})

            const formData = new FormData(event.target)
            const data = Object.fromEntries(formData.entries())

            if (data.username == "" || !data.username)
            {
                setErrorMessage("Please enter a username.")
                return
            }

            fetch(`https://api.github.com/users/${data.username}`)
            .then(response => response.json())
            .then(apiData => {

                if (apiData.message && apiData.message == "Not Found")
                {
                    setErrorMessage("Username was not found.")
                    return
                }
                
                setUserData(apiData)
                console.log("data", apiData)
            })
        }

    return (
        <div className="grid place-items-center w-full h-32">
            <div>
                <form onSubmit={handleSubmit} id="search-form" className = "flex items-center gap-3">
                    <input type="search" name="username" placeholder="Enter Github username" className="border rounded-md p-2"/>
                    <button type="submit" className="bg-blue-400 text-white rounded px-4 py-2">Search</button>
                </form>
    
            </div>
        </div>
        )
    }

const GithubAppContext = createContext({
    userData: {},
    setUserData: () => { },
    errorMessage: "",
    setErrorMessage: () => { }
})

function GithubAppProvider({children})
{
    const [errorMessage, setErrorMessage] = useState("")
    const [userData, setUserData] = useState({})

    return(
        <GithubAppContext.Provider value = {{userData, setUserData, errorMessage, setErrorMessage}}>
            {children}
        </GithubAppContext.Provider>
    )
}

export default function GithubApp() {
    return (
        <GithubAppProvider>
        <div>
            <SearchForm/>
            <ErrorMessage/>
            <UserDetails/>
        </div>
        </GithubAppProvider>
    )

}
