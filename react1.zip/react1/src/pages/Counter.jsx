import React, { useState } from 'react'

export default function Counter() {
const [counter, setCounter] = useState(0)

function changeCounter(value)
{
    setCounter(counter + value)
}

function setCounterTo(value)
{
    setCounter(value)
}

  return (
    <div className="mt-6">
        <li className="flex items-center gap-5 px-2">
          <button class="bg-blue-500 text-white font-bold px-2 rounded" onClick={() => changeCounter(-1)}>-</button>
          <span className='text-blue-800 font-semibold text-3xl'>{counter}</span>
          <button class="bg-blue-500 text-white font-bold px-2 rounded" onClick={() => changeCounter(1)}>+</button>
          <button class="bg-red-500 text-white font-bold px-2 rounded" onClick={() => setCounterTo(0)}>Reset</button>
        </li>
    </div>
  )
}
