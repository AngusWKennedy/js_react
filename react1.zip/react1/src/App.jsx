import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Heading from './components/Heading'
import Paragraph from './components/Paragraph'
import Counter from './pages/Counter'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import TodoList from './pages/TodoList'
import Layout from './components/Layout'
import Contacts from './pages/Contacts'
import ContactDetails from './pages/ContactDetails'
import GithubApp from './pages/GithubApp'

function App() {
  return(
    <BrowserRouter>
      <Routes>
        <Route path = "/" element = {<Layout />}>
          <Route index element = {<Counter />}></Route>
          <Route path = "/todo-list" element = {<TodoList />}></Route>
          <Route path = "/contacts" element = {<Contacts />}></Route>
          <Route path = "/contacts/:name" element = {<ContactDetails />}></Route>
          <Route path = "/github-app" element = {<GithubApp />}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
